#!/bin/bash

javac -d bin src/skiingCentre/*.java src/skiingCentre/engine/*.java src/skiingCentre/event/*.java src/skiingCentre/infrastructure/*.java

java -ea -cp bin skiingCentre.Simulation
