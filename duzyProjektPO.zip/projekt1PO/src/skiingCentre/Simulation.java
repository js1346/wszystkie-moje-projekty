package skiingCentre;

import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

import skiingCentre.engine.*;
import skiingCentre.Athlete;
import skiingCentre.infrastructure.*;
import skiingCentre.event.*;

public class Simulation {
    static Random random;
    static EventQueue eventQueue;

    static {
        random = new Random();
        eventQueue = new Heap();
    }

    public static Random random() {
        return random;
    }

    public static void main(String[] args) {
        parseInput();
        processQueue();
        printStatistics();
    }

    public static void processQueue() {
        Event event;
        while (!eventQueue.isEmpty()) {
            event = eventQueue.pollEvent();
            event.execute();
        }
    }

    public static void printStatistics() {
        System.out.println("Ride statistics:");
        for (int i = 0; i < SkiLift.totalCount(); i++) {
            System.out.println("Ski lift no: " + i + " - " + SkiLift.peopleCountOnSkiLift(i) + " people");
        }
        for (int i = 0; i < Route.totalCount(); i++) {
            System.out.println("Route no: " + i + " - " + Route.peopleCountOnRoute(i) + " people");
        }
    }

    public static void parseInput() {
        Scanner fullLineScanner = new Scanner(System.in);

        int knotsCount = fullLineScanner.nextInt();
        fullLineScanner.nextLine();
        for (int i = 0; i < knotsCount; i++) {
            String line = fullLineScanner.nextLine();
            parseKnot(line);
        }

        fullLineScanner.nextLine(); // Ommiting of empty line

        int skiLiftsCount = fullLineScanner.nextInt();
        fullLineScanner.nextLine();// finishing the line of int
        for (int i = 0; i < skiLiftsCount; i++) {
            String line = fullLineScanner.nextLine();
            parseSkiLift(line);
        }

        fullLineScanner.nextLine(); // Ommiting of empty line
        int routesCount = fullLineScanner.nextInt();
        fullLineScanner.nextLine();
        for (int i = 0; i < routesCount; i++) {
            String line = fullLineScanner.nextLine();
            parseRoute(line);
        }

        fullLineScanner.nextLine(); // Ommiting of empty line

        int athleteGroupsCount = fullLineScanner.nextInt();
        fullLineScanner.nextLine();
        for (int i = 0; i < athleteGroupsCount; i++) {
            String[] lines = new String[3];
            for (int j = 0; j < 3; j++) {
                lines[j] = fullLineScanner.nextLine();
            }
            parseAthleteGroup(lines);
        }
    }

    public static void parseKnot(String line) {
        Scanner singleLineScanner = new Scanner(line);
        singleLineScanner.useLocale(Locale.ENGLISH);

        long elevation = singleLineScanner.nextLong();
        long x = singleLineScanner.nextLong();
        long y = singleLineScanner.nextLong();
        boolean isTransferKnot = singleLineScanner.hasNext("s");

        new Knot(elevation, x, y, isTransferKnot);
    }

    public static void parseSkiLift(String line) {
        Scanner singleLineScanner = new Scanner(line);
        singleLineScanner.useLocale(Locale.ENGLISH);

        int startKnotId = singleLineScanner.nextInt();
        int endKnotId = singleLineScanner.nextInt();
        int timeInterval = singleLineScanner.nextInt();
        long cabinCapacity = singleLineScanner.nextLong();
        long travelTime = singleLineScanner.nextLong();

        Knot startKnot = Knot.get(startKnotId);
        Knot endKnot = Knot.get(endKnotId);

        SkiLift skiLift = new SkiLift(startKnot, endKnot, travelTime, cabinCapacity, timeInterval);
        eventQueue.insertEvent(new LiftCycle(new Time("9:00:00"), skiLift, eventQueue));
    }

    public static void parseRoute(String line) {
        Scanner singleLineScanner = new Scanner(line);
        singleLineScanner.useLocale(Locale.ENGLISH);

        int startKnotId = singleLineScanner.nextInt();
        int endKnotId = singleLineScanner.nextInt();
        int difficultyLevel = singleLineScanner.nextInt();
        long travelTime = singleLineScanner.nextLong();
        double baseAttractiveness = singleLineScanner.nextDouble();
        double wearResistance = singleLineScanner.nextDouble();

        Knot startKnot = Knot.get(startKnotId);
        Knot endKnot = Knot.get(endKnotId);

        new Route(difficultyLevel, baseAttractiveness, wearResistance, startKnot, endKnot, travelTime);
    }

    public static void parseAthleteGroup(String[] lines) {
        Scanner[] scanners = new Scanner[3];
        for (int i = 0; i < 3; i++) {
            scanners[i] = new Scanner(lines[i]);
            scanners[i].useLocale(Locale.ENGLISH);
        }

        int athletesCount = scanners[0].nextInt();
        int skillLevel = scanners[0].nextInt();
        double spontaneityFactor = scanners[0].nextDouble();
        boolean isTracked = scanners[0].hasNext("s");

        double skillWeight = scanners[1].nextDouble();
        double surfaceWeight = scanners[1].nextDouble();

        int knotId = scanners[2].nextInt();
        String timeString = scanners[2].next();

        Knot knot = Knot.get(knotId);
        Time time = new Time(timeString);

        int secondsToAdd = 0;
        if (scanners[2].hasNextInt()) {
            secondsToAdd = scanners[2].nextInt();
        }

        for (int i = 0; i < athletesCount; i++) {
            Athlete athlete = new Athlete(spontaneityFactor, skillLevel, surfaceWeight, skillWeight, isTracked);
            Time athleteTime = new Time(time, i * secondsToAdd);
            Event event = new Decision(athleteTime, athlete, knot, eventQueue);
            eventQueue.insertEvent(event);
        }
    }
}
