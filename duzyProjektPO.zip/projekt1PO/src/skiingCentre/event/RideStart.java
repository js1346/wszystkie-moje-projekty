package skiingCentre.event;

import skiingCentre.infrastructure.GraphEdge;
import skiingCentre.engine.*;
import skiingCentre.Athlete;

public class RideStart extends AthleteEvent {
    private GraphEdge edge;

    public RideStart(Time time, Athlete athlete, GraphEdge edge, EventQueue eventQueue) {
        super(time, athlete, eventQueue);
        this.edge = edge;
    }

    @Override
    public void execute() {
        Time newTime = new Time(time, edge.travelTime());
        edge.incrementPeopleCount();
        RideEnd rideEnd = new RideEnd(newTime, athlete, edge, eventQueue);
        eventQueue.insertEvent(rideEnd);
        printEvent();
    }

    private void printEvent() {
        if (athlete.isTracked()) {
            if (edge.isSkiLift()) {
                System.out.println(time.formattedTime() + ": athlete nr: " + athlete.number()
                        + " started ride on ski lift numbered: " + edge.number());
            } else {
                System.out.println(time.formattedTime() + ": athlete nr: " + athlete.number()
                        + " started ride on route numbered: " + edge.number());
            }
        }
    }
}
