package skiingCentre.event;

import skiingCentre.infrastructure.GraphEdge;
import skiingCentre.engine.*;
import skiingCentre.Athlete;

public class RideEnd extends AthleteEvent {
    private GraphEdge edge;

    public RideEnd(Time time, Athlete athlete, GraphEdge edge, EventQueue eventQueue) {
        super(time, athlete, eventQueue);
        this.edge = edge;
    }

    @Override
    public void execute() {
        if (time.isBefore15()) {
            eventQueue.insertEvent(new Decision(time, athlete, edge.endKnot(), eventQueue));
        }
        printEvent();
    }

    private void printEvent() {
        if (athlete.isTracked()) {
            if (edge.isSkiLift()) {
                System.out.println(time.formattedTime() + ": athlete nr: " + athlete.number()
                        + " ended ride on ski lift number: " + edge.number());
            } else {
                System.out.println(time.formattedTime() + ": athlete nr: " + athlete.number()
                        + " ended ride on route number: " + edge.number());
            }
        }
    }
}
