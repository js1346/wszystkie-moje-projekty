package skiingCentre.event;

import skiingCentre.Athlete;
import skiingCentre.engine.*;

public abstract class AthleteEvent extends Event {
    protected Athlete athlete;

    public AthleteEvent(Time time, Athlete athlete, EventQueue eventQueue) {
        super(time, eventQueue);
        this.athlete = athlete;
    }

    public Athlete athlete() {
        return athlete;
    }
}
