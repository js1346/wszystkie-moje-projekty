package skiingCentre.event;

import skiingCentre.Simulation;
import skiingCentre.engine.*;
import skiingCentre.Athlete;
import skiingCentre.infrastructure.*;

public class Decision extends AthleteEvent {
    private Knot knot;

    public Decision(Time time, Athlete athlete, Knot knot, EventQueue eventQueue) {
        super(time, athlete, eventQueue);
        this.knot = knot;
    }

    @Override
    public void execute() {
        double randomValue = Simulation.random().nextDouble(0.0, 1.0);
        GraphEdge bestEdge = knot.edge(0);

        if (randomValue < athlete.spontaneityFactor()) {
            int randomEdgeIndex = Simulation.random().nextInt(0, knot.outgoingCount());
            bestEdge = knot.edge(randomEdgeIndex);
        } else {
            double bestAttractiveness = knot.edge(0).attractivenessForAthlete(athlete);
            bestEdge = knot.edge(0);

            for (int i = 1; i < knot.outgoingCount(); i++) {
                double tempAttractiveness = knot.edge(i).attractivenessForAthlete(athlete);
                if (tempAttractiveness > bestAttractiveness) {
                    bestEdge = knot.edge(i);
                    bestAttractiveness = tempAttractiveness;
                }
            }
        }

        if (!bestEdge.isSkiLift()) {
            RideStart rideStart = new RideStart(time, athlete, bestEdge, eventQueue);
            if (time.isBefore15()) {
                eventQueue.insertEvent(rideStart);
            }
        } else {
            if (time.isBefore15()) {
                bestEdge.enqueue(athlete);
                printQueueEvent(bestEdge);
            }
        }
    }

    private void printQueueEvent(GraphEdge bestEdge) {
        if (athlete.isTracked()) {
            System.out.println(time.formattedTime() + ": athlete number: " + athlete.number()
                    + " stood in queue numbered: " + bestEdge.number());
        }
    }
}
