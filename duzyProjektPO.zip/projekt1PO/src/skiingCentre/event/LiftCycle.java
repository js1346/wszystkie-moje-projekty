package skiingCentre.event;

import skiingCentre.engine.*;
import skiingCentre.Athlete;
import skiingCentre.infrastructure.SkiLift;

public class LiftCycle extends Event {
    private SkiLift skiLift;

    public LiftCycle(Time time, SkiLift skiLift, EventQueue eventQueue) {
        super(time, eventQueue);
        this.skiLift = skiLift;
    }

    @Override
    public void execute() {
        int remainingSeats = skiLift.cabinCapacity();
        Time newTime = new Time(time, skiLift.timeInterval());

        if (time.isBefore16()) {
            eventQueue.insertEvent(new LiftCycle(newTime, skiLift, eventQueue));
        }

        while (!skiLift.isQueueEmpty() && remainingSeats != 0) {
            Athlete athlete = skiLift.pollAthlete();
            eventQueue.insertEvent(new RideStart(time, athlete, skiLift, eventQueue));
            remainingSeats--;
            // we write nothnig here
        }
    }
}
