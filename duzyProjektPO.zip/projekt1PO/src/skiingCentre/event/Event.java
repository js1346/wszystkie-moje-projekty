package skiingCentre.event;

import skiingCentre.engine.*;

public abstract class Event {
    protected Time time;
    protected static int nextId = 0;
    protected int id;
    protected EventQueue eventQueue;

    public Event(Time time, EventQueue eventQueue) {
        this.eventQueue = eventQueue;
        this.time = time;
        this.id = nextId;
        nextId++;
    }

    public Time time() {
        return time;
    }

    public int id() {
        return id;
    }

    public boolean isBefore(Event other) {
        if (this.time.moment() < other.time.moment()) {
            return true;
        }
        if (this.time.moment() > other.time.moment()) {
            return false;
        }
        return this.id < other.id;
    }

    public abstract void execute();
}
