package skiingCentre.engine;

import java.util.Scanner;

public class Time {
    private int timeInSeconds;

    public Time(String timeString) {
        Scanner scanner = new Scanner(timeString);
        scanner.useDelimiter(":");
        int hours = scanner.nextInt();
        int minutes = scanner.nextInt();
        int seconds = scanner.nextInt();
        this.timeInSeconds = seconds + 60 * minutes + 3600 * hours;
    }

    public Time(Time time, int secondsToAdd) {
        this.timeInSeconds = time.moment();
        this.add(secondsToAdd);
    }

    public void add(int secondsToAdd) {
        timeInSeconds += secondsToAdd;
    }

    public boolean isBefore15() {
        return timeInSeconds < 3600 * 15;
    }

    public boolean isBefore16() {
        return timeInSeconds < 3600 * 16;
    }

    public int moment() {
        return timeInSeconds;
    }

    public String formattedTime() {
        int hours = timeInSeconds / 3600;
        int minutes = (timeInSeconds % 3600) / 60;
        int seconds = timeInSeconds % 60;

        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
}
