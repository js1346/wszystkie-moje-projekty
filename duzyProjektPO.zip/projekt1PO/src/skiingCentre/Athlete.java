package skiingCentre;

import skiingCentre.engine.Time;

public class Athlete {
    private static long nextId = 0;
    private long id;
    private double spontaneityFactor;
    private int skillLevel;
    private double surfaceWeight;
    private double skillWeight;
    private boolean isTracked;
    private Time time;

    public Athlete(double spontaneityFactor, int skillLevel, double surfaceWeight,
            double skillWeight, boolean isTracked) {
        this.spontaneityFactor = spontaneityFactor;
        this.skillLevel = skillLevel;
        this.surfaceWeight = surfaceWeight;
        this.skillWeight = skillWeight;
        this.isTracked = isTracked;
        this.id = nextId;
        nextId++;
    }

    public double spontaneityFactor() {
        return spontaneityFactor;
    }

    public double surfaceWeight() {
        return surfaceWeight;
    }

    public double skillWeight() {
        return skillWeight;
    }

    public boolean isTracked() {
        return isTracked;
    }

    public int skillLevel() {
        return skillLevel;
    }

    public int number() {
        return (int) id;
    }
}
