package skiingCentre.infrastructure;

import skiingCentre.Athlete;

public class GraphEdge {
    protected Knot startKnot;
    protected Knot endKnot;
    protected long travelTime;
    protected int peopleCount;
    protected boolean isSkiLift;

    public GraphEdge(Knot startKnot, Knot endKnot, long travelTime) {
        this.endKnot = endKnot;
        this.startKnot = startKnot;
        startKnot.addEdge(this);
        this.travelTime = travelTime;
        this.peopleCount = 0;
    }

    public boolean isSkiLift() {
        return isSkiLift;
    }

    public double attractivenessForAthlete(Athlete athlete) {
        return 0; // stub, overridden in subclasses
    }

    public void incrementPeopleCount() {
        peopleCount++;
    }

    public void enqueue(Athlete athlete) {
        // stub, overridden in subclasses
    }

    public int number() {
        return 0; // stub, overridden in subclasses
    }

    public int travelTime() {
        return (int) travelTime;
    }

    public Knot endKnot() {
        return endKnot;
    }

    public int peopleCount() {
        return peopleCount;
    }
}
