package skiingCentre.infrastructure;

public class Knot {
    private static Knot[] list;
    private static int knotIndex;
    private static int listCapacity;

    private long elevation;
    private long x;
    private long y;
    private boolean isTransferKnot;

    private GraphEdge[] outgoingEdges;
    private int edgesCapacity;
    private int edgeIndex;

    static {
        Knot.list = new Knot[10];
        Knot.knotIndex = 0;
        Knot.listCapacity = 10;
    }

    private static void addKnot(Knot knot) {
        if (knotIndex >= listCapacity) {
            Knot[] temp = new Knot[2 * listCapacity];
            for (int i = 0; i < knotIndex; i++) {
                temp[i] = Knot.list[i];
            }
            listCapacity *= 2; // Naprawione: aktualizacja limitu tablicy statycznej
            Knot.list = temp;
        }

        if (knotIndex < listCapacity) {
            Knot.list[knotIndex] = knot;
            knotIndex++;
        }
    }

    public static Knot get(int i) {
        return Knot.list[i];
    }

    public Knot(long elevation, long x, long y, boolean isTransferKnot) {
        this.elevation = elevation;
        this.x = x;
        this.y = y;
        this.isTransferKnot = isTransferKnot;
        this.outgoingEdges = new GraphEdge[10];
        this.edgesCapacity = 10;
        this.edgeIndex = 0;
        Knot.addKnot(this);
    }

    public int outgoingCount() {
        return this.edgeIndex;
    }

    public GraphEdge edge(int i) {
        return outgoingEdges[i];
    }

    public void addEdge(GraphEdge edge) {
        if (edgeIndex >= edgesCapacity) {
            GraphEdge[] temp = new GraphEdge[2 * edgesCapacity];
            for (int i = 0; i < edgeIndex; i++) {
                temp[i] = this.outgoingEdges[i];
            }
            edgesCapacity *= 2;
            this.outgoingEdges = temp;
        }

        if (edgeIndex < edgesCapacity) {
            this.outgoingEdges[edgeIndex] = edge;
            edgeIndex++;
        }
    }
}
