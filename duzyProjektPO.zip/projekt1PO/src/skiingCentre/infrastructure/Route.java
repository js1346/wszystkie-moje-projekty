package skiingCentre.infrastructure;

import skiingCentre.Athlete;

import java.lang.Math;

public class Route extends GraphEdge {
    private static int routeCount;
    private static int capacity;
    private static Route[] routes;

    private int difficultyLevel;
    private double baseAttractiveness;
    private double wearResistance;
    private int id;

    static {
        routes = new Route[10];
        capacity = 10;
        routeCount = 0;
    }

    public static void push(Route route) {
        if (routeCount >= capacity) {
            Route[] temp = new Route[2 * capacity];
            for (int i = 0; i < capacity; i++) {
                temp[i] = routes[i];
            }
            routes = temp;
            capacity *= 2;
        }
        routes[routeCount] = route;
        routeCount++;
    }

    public static int totalCount() {
        return routeCount;
    }

    public static int peopleCountOnRoute(int i) {
        return routes[i].peopleCount;
    }

    public Route(int difficultyLevel, double baseAttractiveness, double wearResistance,
            Knot startKnot, Knot endKnot, long travelTime) {

        super(startKnot, endKnot, travelTime);
        super.isSkiLift = false;
        this.difficultyLevel = difficultyLevel;
        this.baseAttractiveness = baseAttractiveness;
        this.wearResistance = wearResistance;
        this.id = routeCount;

        Route.push(this);
    }

    @Override
    public double attractivenessForAthlete(Athlete athlete) {
        double pn = athlete.skillLevel();
        double pt = difficultyLevel;

        double difficultyAttractiveness = 0;

        if (pn + 5 > pt && pt >= pn) {
            difficultyAttractiveness = 1 - 0.2 * pt + 0.2 * pn;
        }
        if (pn > pt) {
            difficultyAttractiveness = Math.max(0.2, 1 - (pn - pt) / 7.0);
        }

        double surfaceAttractiveness = baseAttractiveness +
                (1 - baseAttractiveness) * Math.pow(wearResistance, super.peopleCount);

        return athlete.skillWeight() * difficultyAttractiveness +
                athlete.surfaceWeight() * surfaceAttractiveness;
    }

    public void enqueue(Athlete athlete) {
        throw new IllegalStateException("You cannot enqueue on route");
    }

    @Override
    public int number() {
        return this.id;
    }
}
