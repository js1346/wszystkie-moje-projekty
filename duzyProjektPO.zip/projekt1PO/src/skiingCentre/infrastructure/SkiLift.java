package skiingCentre.infrastructure;

import skiingCentre.Athlete;

public class SkiLift extends GraphEdge {
    private static int liftCount = 0;
    private static int capacity = 10;
    private static SkiLift[] skiLifts;

    private long cabinCapacity;
    private int timeInterval;
    private int id;
    private AthleteQueue athleteQueue;

    static {
        skiLifts = new SkiLift[10];
        capacity = 10;
        liftCount = 0;
    }

    public static void push(SkiLift skiLift) {
        if (liftCount >= capacity) {
            SkiLift[] temp = new SkiLift[2 * capacity];
            for (int i = 0; i < capacity; i++)
                temp[i] = skiLifts[i];
            skiLifts = temp;
            capacity *= 2;
        }
        skiLifts[liftCount] = skiLift;
        liftCount++;
    }

    public static int totalCount() {
        return liftCount;
    }

    public static int peopleCountOnSkiLift(int i) {
        return skiLifts[i].peopleCount;
    }

    public SkiLift(Knot startKnot, Knot endKnot, long travelTime,
            long cabinCapacity, int timeInterval) {
        super(startKnot, endKnot, travelTime);
        this.cabinCapacity = cabinCapacity;
        this.timeInterval = timeInterval;
        this.id = liftCount;
        this.athleteQueue = new AthleteQueue();
        super.isSkiLift = true;
        SkiLift.push(this);
    }

    @Override
    public double attractivenessForAthlete(Athlete athlete) {
        double maxAttractiveness = 0;
        for (int i = 0; i < endKnot.outgoingCount(); i++) {
            GraphEdge edge = endKnot.edge(i);
            if (edge.isSkiLift())
                continue;
            maxAttractiveness = Math.max(maxAttractiveness,
                    edge.attractivenessForAthlete(athlete));
        }
        return maxAttractiveness;
    }

    private class AthleteQueue {
        private QueueNode head;
        private QueueNode tail;
        private int counter;

        public AthleteQueue() {
            this.head = null;
            this.tail = null;
            this.counter = 0;
        }

        public void enqueue(Athlete athlete) {
            if (tail == null) {
                QueueNode temp = new QueueNode(null, null, athlete);
                head = temp;
                tail = temp;
            } else {
                QueueNode temp = new QueueNode(null, tail, athlete);
                tail.next = temp;
                tail = temp;
            }
            counter++;
        }

        public Athlete poll() {
            if (head == null)
                return null;
            Athlete toReturn = head.athlete;
            if (head.next == null) {
                head = null;
                tail = null;
            } else {
                head.next.prev = null;
                head = head.next;
            }
            counter--;
            return toReturn;
        }

        public boolean isEmpty() {
            return counter == 0;
        }

        private class QueueNode {
            public QueueNode next;
            public QueueNode prev;
            public Athlete athlete;

            QueueNode(QueueNode next, QueueNode prev, Athlete athlete) {
                this.next = next;
                this.prev = prev;
                this.athlete = athlete;
            }
        }
    }

    public int timeInterval() {
        return timeInterval;
    }

    public Athlete pollAthlete() {
        return athleteQueue.poll();
    }

    @Override
    public void enqueue(Athlete athlete) {
        athleteQueue.enqueue(athlete);
    }

    public boolean isQueueEmpty() {
        return athleteQueue.isEmpty();
    }

    @Override
    public int number() {
        return this.id;
    }

    public int cabinCapacity() {
        return (int) cabinCapacity;
    }
}
