#SkiingCentre
This project's goal is to perform a simplified simulation of skiing centre for every ride starting before 15.00. It's structure is based on queue of event's. Package event is responsible for managing the events (putting new events being consequence of earlier events).Package infrastructure manages places and package engines contains of classes nessecary to perform the simulation, class simulation is main clas which performs all system.
How to use the program?
being in this folder write in terminal ./run.sh and put data according to file describing the task.
How does this program work(in details?):
1-This program performs simulation on one skiing centre and uses static methods of class to enlist its objects, in another versions of this program it's possible to create new classes like KnotSet,RouteSet etc.
2a-class Knot stores the information about knot
2b-class GraphEdge is superclass for lifts and routes, it stores information useful for both classes and stubs implemented in extending classes
2c-class Route extends GraphEdge stores extra information and implements atractivenes for athlete
2d-class Skilift extends GraphEdge implements atractivenes for athlete and manages the queue of athletes for every skilift (it contains the methods to put athletes in it and remove them from queue using nested class athletequeue and nested in it class node using linked list)
3-super class Event stores minimal information about event and gives method time to analyse, which event should be first based on it's time
3a-class LiftCycle uses methods given by skilift to manage queue in skilift make new events ride start and put next ride of Lift
3b-AthleteEvent class is intermediate class storing information about athlete
3ba-Decision extending AthleteEvent is making the decision about what athlete will do next. If he choses ride with ski lift it puts athlete to queue in this skilift and prints info about being in queue. If he choses to ride on route it puts RideStart event.
3bb-RideStart writes info ,calculates the finish of ride,incremets the count on graphEdge and puts rideEnd event
3bc-RideEnd writes info and puts decision event
3c-every event is put only, when it's time is before 15.00
4a-engine-EventQueue is interface of priority queue
4b-Heap implements EventQueue using heap with classical methods and auxiliary methods to make easier to use indexes
4c-Time gives two constructors used in code and formats printing the hour
5-athlete stores info about athlete
6-simulation performs whole simulation using short main loop and three functions used in short main loop